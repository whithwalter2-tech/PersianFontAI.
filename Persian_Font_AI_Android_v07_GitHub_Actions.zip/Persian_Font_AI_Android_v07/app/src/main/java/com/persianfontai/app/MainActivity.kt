package com.persianfontai.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as NativeCanvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF071B35)
private val Panel = Color(0xFF102D50)
private val Cyan = Color(0xFF39D6D0)
private val Blue = Color(0xFF2588D8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PersianFontAIApp() }
    }
}

@Composable
private fun PersianFontAIApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var original by remember { mutableStateOf<Bitmap?>(null) }
    var processed by remember { mutableStateOf<Bitmap?>(null) }
    var brightness by remember { mutableFloatStateOf(1f) }
    var contrast by remember { mutableFloatStateOf(1.15f) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                val bitmap = context.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it)
                }
                if (bitmap != null) {
                    original = bitmap
                    processed = processBitmap(bitmap, brightness, contrast)
                } else {
                    Toast.makeText(context, "خواندن تصویر ممکن نشد", Toast.LENGTH_SHORT).show()
                }
            } catch (_: Exception) {
                Toast.makeText(context, "خطا در باز کردن عکس", Toast.LENGTH_SHORT).show()
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, secondary = Blue, background = Navy, surface = Panel,
        onPrimary = Navy, onBackground = Color.White, onSurface = Color.White
    )) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Navy, Color(0xFF0A3152), Color(0xFF075568)))
            )
        ) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(
                    Modifier.fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(listOf(Color(0xFF0E4266), Color(0xFF087B83))),
                            RoundedCornerShape(24.dp)
                        ).padding(22.dp)
                ) {
                    Text("Persian Font AI", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Text("ساخت فونت اختصاصی از دست‌خط فارسی", color = Color(0xFFD7F7F5))
                    Text("نسخه اندروید ۰٫۷", color = Color(0xFF9BEDE7), fontSize = 12.sp)
                }

                AppCard("مرحله ۱ | آماده‌سازی دست‌خط") {
                    Text(
                        "تمام حروف الفبای فارسی را روی کاغذ بنویس و چند جمله کامل هم اضافه کن. جمله‌ها کمک می‌کنند شکل حروف در ابتدا، وسط و انتهای کلمه و نحوه اتصال آن‌ها بهتر شناخته شود.",
                        fontSize = 15.sp, fontWeight = FontWeight.SemiBold
                    )
                    Text("حروف فارسی", color = Cyan, fontWeight = FontWeight.Bold)
                    Text(
                        "ا ب پ ت ث ج چ ح خ د ذ ر ز ژ س ش ص ض ط ظ ع غ ف ق ک گ ل م ن و ه ی",
                        fontSize = 20.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                    )
                    Text("جمله‌های نمونه", color = Cyan, fontWeight = FontWeight.Bold)
                    listOf(
                        "امروز هوا بسیار خوب است و من خوشحال هستم.",
                        "من هر روز کتاب می‌خوانم و چیزهای تازه یاد می‌گیرم.",
                        "زندگی زیباست؛ پس با امید و تلاش به راه خود ادامه می‌دهیم.",
                        "پرنده‌ای کوچک روی شاخه درخت نشسته بود."
                    ).forEachIndexed { index, sentence ->
                        Text("${index + 1}. $sentence", color = Color(0xFFD7EAF7), fontSize = 14.sp)
                    }
                }

                AppCard("مرحله ۲ | انتخاب عکس دست‌خط") {
                    Text("از برگه نوشته‌شده عکس واضح و بدون سایه بگیر.", color = Color(0xFFB8CDE0))
                    Button(
                        onClick = { picker.launch("image/*") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Navy)
                    ) {
                        Text(if (original == null) "انتخاب عکس از گوشی" else "انتخاب عکس دیگر", fontWeight = FontWeight.Bold)
                    }
                    original?.let {
                        Text("عکس اصلی", color = Cyan, fontWeight = FontWeight.Bold)
                        Image(
                            bitmap = it.asImageBitmap(),
                            contentDescription = "عکس اصلی دست‌خط",
                            modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp)
                        )
                    }
                }

                AppCard("مرحله ۳ | تنظیم و پردازش عکس") {
                    Text("روشنایی: ${(brightness * 100).toInt()}٪")
                    Slider(
                        value = brightness,
                        onValueChange = {
                            brightness = it
                            original?.let { source -> processed = processBitmap(source, brightness, contrast) }
                        },
                        valueRange = 0.5f..1.6f,
                        enabled = original != null
                    )
                    Text("کنتراست: ${(contrast * 100).toInt()}٪")
                    Slider(
                        value = contrast,
                        onValueChange = {
                            contrast = it
                            original?.let { source -> processed = processBitmap(source, brightness, contrast) }
                        },
                        valueRange = 0.5f..2f,
                        enabled = original != null
                    )
                    Button(
                        onClick = { original?.let { processed = processBitmap(it, brightness, contrast) } },
                        enabled = original != null,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Blue)
                    ) { Text("پردازش دوباره عکس") }
                    processed?.let {
                        Text("پیش‌نمایش پردازش‌شده", color = Cyan, fontWeight = FontWeight.Bold)
                        Image(
                            bitmap = it.asImageBitmap(),
                            contentDescription = "عکس پردازش‌شده",
                            modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp)
                        )
                        OutlinedButton(
                            onClick = { saveBitmap(context, it) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("ذخیره تصویر پردازش‌شده در گوشی", color = Cyan) }
                    }
                }

                AppCard("مرحله ۴ | ادامه پروژه") {
                    Text(
                        "این نسخه عکس را خاکستری می‌کند و روشنایی و کنتراست آن را تنظیم می‌کند. هنوز تشخیص خودکار دست‌خط یا تولید فونت TTF ندارد؛ این قابلیت‌ها در مراحل بعدی توسعه داده می‌شوند.",
                        color = Color(0xFFD7EAF7), fontSize = 14.sp
                    )
                }
                Text(
                    "Persian Font AI • نسخه آزمایشی",
                    color = Color(0xFFAAC4D8), fontSize = 11.sp,
                    textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun AppCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Panel.copy(alpha = 0.97f), RoundedCornerShape(20.dp)).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(title, color = Cyan, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        content()
    }
}

private fun processBitmap(source: Bitmap, brightness: Float, contrast: Float): Bitmap {
    val maxSide = 2200
    val scale = minOf(1f, maxSide.toFloat() / maxOf(source.width, source.height))
    val width = (source.width * scale).toInt().coerceAtLeast(1)
    val height = (source.height * scale).toInt().coerceAtLeast(1)
    val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = NativeCanvas(output)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    val offset = 128f * (1f - contrast)
    val matrix = ColorMatrix(floatArrayOf(
        0.299f * contrast, 0.587f * contrast, 0.114f * contrast, 0f, offset,
        0.299f * contrast, 0.587f * contrast, 0.114f * contrast, 0f, offset,
        0.299f * contrast, 0.587f * contrast, 0.114f * contrast, 0f, offset,
        0f, 0f, 0f, 1f, 0f
    ))
    matrix.postConcat(ColorMatrix().apply { setScale(brightness, brightness, brightness, 1f) })
    paint.colorFilter = ColorMatrixColorFilter(matrix)
    canvas.drawBitmap(source, null, Rect(0, 0, width, height), paint)
    return output
}

private fun saveBitmap(context: Context, bitmap: Bitmap) {
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "persian-font-handwriting-processed.png")
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PersianFontAI")
    }
    val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
    if (uri == null) {
        Toast.makeText(context, "ذخیره تصویر انجام نشد", Toast.LENGTH_SHORT).show()
        return
    }
    val success = context.contentResolver.openOutputStream(uri)?.use {
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
    } ?: false
    Toast.makeText(
        context,
        if (success) "تصویر در Pictures/PersianFontAI ذخیره شد" else "ذخیره تصویر انجام نشد",
        Toast.LENGTH_LONG
    ).show()
}
